package rentalservice.manage;




import java.util.ArrayList;


import rentalservice.user.DBConn;


public class shoppingBasketDAO extends DBConn {

	public shoppingBasketDAO() {
	}




	public static String [][] getData() {
		ArrayList<String []> lst = new ArrayList<String[]>();
		try {
			getConn();
			sql = "select * from tbl_orderuser";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				lst.add(new String[] {
						rs.getString("orderuser_name"),
						rs.getString("orderuser_ename"),
						rs.getString("orderuser_zipcode"),
						rs.getString("orderuser_address"),
						rs.getString("orderuser_birth"),
						rs.getString("orderuser_tel"),
						rs.getString("orderuser_email")

				});


			}
			String [][] arr = new String[lst.size()][7];

			System.out.println("data in ?! ");

			return lst.toArray(arr);

		} catch (Exception e) {

			e.printStackTrace();
			return null;
		} finally {
			dbClose();
		}

	}
}